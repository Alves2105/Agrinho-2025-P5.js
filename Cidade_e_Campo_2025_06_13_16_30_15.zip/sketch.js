function setup() {
  createCanvas(800, 600);

  noLoop();
}

function draw() {
  background(135, 206, 235); // Céu azul

  // Sol

  fill(255, 204, 0);

  ellipse(700, 100, 80, 80);

  // Cidade

  drawCity();

  // Campo

  drawField();

  // Árvores no campo

  drawTrees(150, 400);

  drawTrees(250, 420);

  drawTrees(350, 410);

  // Personagens

  drawCityPerson(600, 500);

  drawFieldPerson(200, 500);
}

// Função para desenhar a cidade

function drawCity() {
  fill(150);

  rect(500, 300, 250, 200); // Prédio grande

  fill(200);

  rect(550, 350, 50, 150); // Prédio menor

  rect(650, 330, 70, 170); // Outro prédio

  fill(0);

  textSize(16);

  text("Cidade", 620, 290);
}

// Função para desenhar o campo

function drawField() {
  fill(34, 139, 34); // Verde do campo

  rect(0, 400, 500, 200);

  fill(0);

  textSize(16);

  text("Campo", 50, 390);
}

// Função para desenhar árvores

function drawTrees(x, y) {
  fill(139, 69, 19); // Tronco

  rect(x, y, 10, 40);

  fill(34, 139, 34); // Folhagem

  ellipse(x + 5, y - 10, 40, 40);
}

// Função para desenhar personagem da cidade

function drawCityPerson(x, y) {
  fill(0);

  ellipse(x, y - 20, 20, 20); // Cabeça

  rect(x - 5, y - 10, 10, 20); // Corpo

  // Braços

  line(x - 5, y - 5, x - 15, y + 5);

  line(x + 5, y - 5, x + 15, y + 5);

  // Pernas

  line(x - 5, y + 10, x - 10, y + 20);

  line(x + 5, y + 10, x + 10, y + 20);
}

// Função para desenhar personagem do campo

function drawFieldPerson(x, y) {
  fill(255, 0, 0);

  ellipse(x, y - 20, 20, 20); // Cabeça

  rect(x - 5, y - 10, 10, 20); // Corpo

  // Braços

  line(x - 5, y - 5, x - 15, y + 5);

  line(x + 5, y - 5, x + 15, y + 5);

  // Pernas

  line(x - 5, y + 10, x - 10, y + 20);

  line(x + 5, y + 10, x + 10, y + 20);
}
